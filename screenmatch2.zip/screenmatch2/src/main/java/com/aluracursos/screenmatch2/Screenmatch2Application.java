package com.aluracursos.screenmatch2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Screenmatch2Application {

	public static void main(String[] args) {
		SpringApplication.run(Screenmatch2Application.class, args);
	}

}
